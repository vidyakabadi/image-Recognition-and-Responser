# Image-Recognition-and-Responser

API detecting a Keyboard is shown here
![Alt text](https://user-images.githubusercontent.com/12893395/36145423-54724928-10d7-11e8-9bae-2023c6c6cf24.png)


API detecting Person is shown here
![Alt text](https://user-images.githubusercontent.com/12893395/36145424-54b4bbb4-10d7-11e8-8747-0ecfb9fbb317.png)

